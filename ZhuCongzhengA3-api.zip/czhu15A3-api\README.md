﻿# Charity Events API (Node.js + Express + MySQL)

PROG2002 Web Development II, Assessment 3.

## Contents

    schema.sql        database schema (categories, events, registrations)
    seed.sql          initial data: 5 categories, 8 events, 14 registrations
    server.js         Express application; also serves the Angular builds on cPanel
    db/               MySQL repository plus an in-memory fallback dataset
    lib/              validation, response shaping and the Open-Meteo integration
    routes/           events, categories, registrations and weather endpoints
    tests/            end-to-end API test suite
    public/           the built Angular websites are served from here on cPanel

## Run it

Import the database first:

    mysql -u <user> -p < schema.sql
    mysql -u <user> -p < seed.sql
    # or paste both files into phpMyAdmin -> SQL

Then:

    npm install
    copy .env.example .env      # edit the database settings
    npm start                   # http://localhost:3000

Verify: GET http://localhost:3000/api/health should report "database":"mysql".

## Tests

    node tests/api.test.js

The suite runs against the in-memory dataset, so it needs no database.

Full project documentation (setup, deployment, video script, marking map) is in
the GitHub repository under README.md and docs/.
