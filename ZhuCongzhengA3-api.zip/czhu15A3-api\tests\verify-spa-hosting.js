'use strict';

/**
 * Behaves like a browser against a running server, to prove a single-page app can
 * actually boot at a sub-path.
 *
 * For each app it:
 *   1. fetches the HTML at the app's URL,
 *   2. reads <base href> and resolves every <script src> / <link href> against it,
 *   3. fetches each asset and checks it returns 200 with a content type the browser
 *      will accept for that kind of file.
 *
 * A blank page is almost always step 3 failing silently, so this is the check that
 * matters.
 *
 *   node tests/verify-spa-hosting.js http://localhost:3000
 */

const BASE = process.argv[2] || 'http://localhost:3000';

let failures = 0;

/** Resolve `ref` against a base path, the way a browser does. */
function resolve(base, ref) {
  if (/^https?:\/\//i.test(ref)) return ref;
  if (ref.startsWith('/')) return ref;
  return base.endsWith('/') ? base + ref : `${base}/${ref}`;
}

/** What content type the browser needs for a given file name. */
function expectedTypes(pathname) {
  if (pathname.endsWith('.js')) return ['javascript'];
  if (pathname.endsWith('.css')) return ['text/css'];
  if (pathname.endsWith('.svg')) return ['image/svg+xml'];
  if (pathname.endsWith('.ico')) return ['image/x-icon', 'image/vnd.microsoft.icon'];
  return null;
}

async function checkApp(label, url, expectTitleIncludes) {
  console.log(`\n=== ${label} ===`);
  console.log(`  URL: ${url}`);

  let html;
  let response;
  try {
    response = await fetch(url);
    html = await response.text();
  } catch (error) {
    console.log(`  FAIL  could not fetch: ${error.message}`);
    failures += 1;
    return;
  }

  console.log(`  HTML status: ${response.status}`);
  if (response.status !== 200) {
    console.log('  FAIL  the HTML itself did not return 200');
    failures += 1;
    return;
  }

  const title = /<title>([^<]*)<\/title>/.exec(html);
  console.log(`  title: ${title ? title[1] : '(none)'}`);
  if (expectTitleIncludes && title && !title[1].includes(expectTitleIncludes)) {
    console.log(`  FAIL  title should contain "${expectTitleIncludes}"`);
    failures += 1;
  }

  const baseMatch = /<base href="([^"]*)"/.exec(html);
  const basePath = baseMatch ? baseMatch[1] : '/';
  console.log(`  <base href>: ${basePath}`);
  if (/app-root/.test(html) === false) {
    console.log('  WARN  no <app-root> element found');
  }
  if (/It works!/i.test(html)) {
    console.log('  FAIL  this is cPanel\'s default app, not the deployed site');
    failures += 1;
    return;
  }

  // Collect every asset the browser would load from the HTML.
  const refs = new Set();
  for (const m of html.matchAll(/<script[^>]+src="([^"]+)"/g)) refs.add(m[1]);
  for (const m of html.matchAll(/<link[^>]+href="([^"]+\.(?:css|ico|svg))"/g)) refs.add(m[1]);

  console.log(`  assets referenced: ${refs.size}`);

  for (const ref of refs) {
    const path = resolve(basePath, ref);
    const assetUrl = new URL(path, url).toString();
    let assetResponse;
    try {
      assetResponse = await fetch(assetUrl);
    } catch (error) {
      console.log(`  FAIL  ${path} -> ${error.message}`);
      failures += 1;
      continue;
    }

    const type = (assetResponse.headers.get('content-type') || '').toLowerCase();
    const wanted = expectedTypes(path);
    const typeOk = !wanted || wanted.some((w) => type.includes(w));

    if (assetResponse.status !== 200 || !typeOk) {
      // Show the first 60 characters of a wrong-type body: if it is HTML, the SPA
      // fallback swallowed the request, which is exactly what causes a blank page.
      let snippet = '';
      if (!typeOk) {
        const body = await assetResponse.text();
        snippet = ` body starts: ${JSON.stringify(body.slice(0, 60))}`;
      }
      console.log(`  FAIL  ${path} -> ${assetResponse.status} content-type="${type}"${snippet}`);
      failures += 1;
    } else {
      const length = (await assetResponse.arrayBuffer()).byteLength;
      console.log(`  ok    ${path} -> ${assetResponse.status} ${type} (${length} bytes)`);
    }
  }
}

(async () => {
  console.log(`Verifying single-page app hosting against ${BASE}`);
  await checkApp('Client app at /', `${BASE}/`, 'Charity Events');
  await checkApp('Admin app at /admin', `${BASE}/admin/`, 'Admin');
  await checkApp('Admin deep link /admin/events', `${BASE}/admin/events`, 'Admin');
  await checkApp('Client deep link /search', `${BASE}/search`, 'Charity Events');

  console.log('');
  if (failures === 0) {
    console.log('PASS - both applications can load their assets and boot.');
    process.exit(0);
  }
  console.log(`FAIL - ${failures} problem(s) found.`);
  process.exit(1);
})();
