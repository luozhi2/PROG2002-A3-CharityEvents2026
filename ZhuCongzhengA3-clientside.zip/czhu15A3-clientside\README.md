﻿# Charity Events - client-side website (Angular)

PROG2002 Web Development II, Assessment 3.

The public-facing website: home, search, event details (including the list of
registrations, newest first), the event registration page, and an about page that
documents which API endpoints each page uses.

## Run it

The website calls the REST API, so start the API first (see the api zip).

    npm install
    npm start          # http://localhost:4200, proxies /api to http://localhost:3000

Build for production:

    npm run build      # output in dist/client/browser

On SCU cPanel the contents of dist/client/browser are served by the Node/Express
API from api/public/client, so no configuration change is needed.
