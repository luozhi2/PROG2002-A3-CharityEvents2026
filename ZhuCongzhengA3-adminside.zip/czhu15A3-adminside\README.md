﻿# Charity Events - admin-side website (Angular)

PROG2002 Web Development II, Assessment 3.

The staff interface for managing charity events: a dashboard, a list of all events
(Active, Past and Suspended), forms to create and update events, and delete with
clear feedback when an event cannot be removed because it has registrations.

## Run it

    npm install
    npm start          # http://localhost:4201, proxies /api to http://localhost:3000

Build for production:

    npm run build      # output in dist/admin/browser

On SCU cPanel the contents of dist/admin/browser are copied to api/public/admin and
served at /admin by the Node/Express API.
